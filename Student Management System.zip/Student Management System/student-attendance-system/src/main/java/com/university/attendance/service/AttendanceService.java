package com.university.attendance.service;

import com.university.attendance.model.AttendanceRecord;
import com.university.attendance.model.AttendanceStatus;
import java.time.LocalDate;
import java.util.List;

public interface AttendanceService {
    AttendanceRecord mark(String studentId, String courseId, LocalDate date, AttendanceStatus status);
    List<AttendanceRecord> getByStudent(String studentId);
    List<AttendanceRecord> getByCourseAndDate(String courseId, LocalDate date);
    List<AttendanceRecord> getByCourse(String courseId);
}
