package com.university.attendance.model;

public enum AttendanceStatus {
    PRESENT,
    ABSENT,
    LATE,
    EXCUSED
}